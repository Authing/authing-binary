//
//  OneAuth.h
//  OneAuth
//
//  Created by Lance Mao on 2021/12/15.
//

#import <Foundation/Foundation.h>

//! Project version number for OneAuth.
FOUNDATION_EXPORT double OneAuthVersionNumber;

//! Project version string for OneAuth.
FOUNDATION_EXPORT const unsigned char OneAuthVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OneAuth/PublicHeader.h>
// haha
#import "NTESQuickPass.h"
