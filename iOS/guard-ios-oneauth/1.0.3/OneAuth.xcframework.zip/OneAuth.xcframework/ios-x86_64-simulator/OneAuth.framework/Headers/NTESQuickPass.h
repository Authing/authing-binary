//
//  NTESQuickPass.h
//  NTESQuickPass
//
//  Created by Xu Ke on 2018/4/10.
//

#import <UIKit/UIKit.h>

//! Project version number for NTESQuickPass.
FOUNDATION_EXPORT double NTESQuickPassVersionNumber;

//! Project version string for NTESQuickPass.
FOUNDATION_EXPORT const unsigned char NTESQuickPassVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NTESQuickPass/PublicHeader.h>

#import "NTESQuickPassManager.h"
#import "NTESQuickLoginManager.h"
#import "NTESQuickLoginModel.h"
