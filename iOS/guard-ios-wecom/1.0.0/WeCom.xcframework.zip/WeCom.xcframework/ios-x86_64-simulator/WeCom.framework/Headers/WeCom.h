//
//  WeCom.h
//  WeCom
//
//  Created by JnMars on 2022/3/23.
//

#import <Foundation/Foundation.h>

//! Project version number for WeCom.
FOUNDATION_EXPORT double WeComVersionNumber;

//! Project version string for WeCom.
FOUNDATION_EXPORT const unsigned char WeComVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeCom/PublicHeader.h>

#import "WWKApi.h"
