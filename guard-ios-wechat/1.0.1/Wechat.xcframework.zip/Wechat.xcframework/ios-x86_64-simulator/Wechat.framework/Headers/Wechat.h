//
//  Wechat.h
//  Wechat
//
//  Created by JnMars on 2022/6/9.
//

#import <Foundation/Foundation.h>

//! Project version number for Wechat.
FOUNDATION_EXPORT double WechatVersionNumber;

//! Project version string for Wechat.
FOUNDATION_EXPORT const unsigned char WechatVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Wechat/PublicHeader.h>

#import "WxApi.h"
